﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace ToolsExtractAPS
{
    public partial class test : Form
    {
        public test()
        {
            InitializeComponent();
        }

        private static string GetConnectionString(string file)
        {
            Dictionary<string, string> props = new Dictionary<string, string>();

            string extension = file.Split('.').Last();

            if (extension == "xls" || extension == "XLS")
            {
                //Excel 2003 and Older
                props["Provider"] = "Microsoft.Jet.OLEDB.4.0";
                props["Extended Properties"] = "'Excel 8.0;HDR=NO;IMEX=1;READONLY=TRUE'";
            }
            else if (extension == "xlsx" || extension == "XLSX" || extension == "xlsm")
            {
                //Excel 2007, 2010, 2012, 2013
                props["Provider"] = "Microsoft.ACE.OLEDB.12.0;";
                props["Extended Properties"] = "'Excel 12.0;HDR=NO;IMEX=1;READONLY=TRUE'";
            }
            else
                throw new Exception(string.Format("error file: {0}", file));

            props["Data Source"] = file;

            StringBuilder sb = new StringBuilder();

            foreach (KeyValuePair<string, string> prop in props)
            {
                sb.Append(prop.Key);
                sb.Append('=');
                sb.Append(prop.Value);
                sb.Append(';');
            }
            //MessageBox.Show(sb.ToString());
            return sb.ToString();

        }

        //private static Excel.Workbook MyBook = null;
        //private static Excel.Application MyApp = null;
        //private static Excel.Worksheet MySheet = null;

        /*private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("test");
            System.Data.DataTable test = new System.Data.DataTable();
            test.Columns.Add("ROW_ID", typeof(int));
            test.Columns.Add("Path", typeof(string));
            test.Columns.Add("APS_No", typeof(string));
            test.Columns.Add("nNo", typeof(string));
            test.Columns.Add("CommentString", typeof(string));
            test.Columns.Add("Fuzzystring", typeof(string));

            List<string> path = new List<string>();

            string directory = @"L:\Data_Setups_PT-HSG\";//5085

            string[] txtArray = Directory.GetFiles(directory, "*.txt", SearchOption.AllDirectories);

            string[] NCArray = Directory.GetFiles(directory, "*.NC", SearchOption.AllDirectories);

            string[] pathArray = txtArray.Concat(NCArray).ToArray();

            foreach (string p in pathArray)
            {
                path.Add(p);
            }

            foreach (string file in path)
            {
                //MessageBox.Show(file);
                if (!file.Contains("old") && Regex.IsMatch(file, @"L:\\\Data_Setups_PT-HSG\\\d{4}\\\d{4}-\d{3}", RegexOptions.Singleline) & !Regex.IsMatch(file, @"(Sub)"))

                {
                    //MessageBox.Show(file);
                    var originalLines = File.ReadAllLines(file);
                    int rowID = 1;
                    string nNumber = "";
                    string apsNo = Regex.Match(file, @"\d{4}-\d{3}", RegexOptions.Singleline).Groups[0].Value.ToString();
                    //string stringtest = @"Anti-Vibration Bar - A570-3C D24 20-32";

                    foreach (var line in originalLines)
                    {
                        string programLine = "";
                        if (line.StartsWith("N"))
                        {
                            //rowID = 1;
                            nNumber = line;
                            //nNumber = Regex.Replace(nNumber, @"\(\s*(.+?)\s*\)", "");
                            nNumber = Regex.Match(line, @"N[\d]+", RegexOptions.Singleline).Groups[0].Value.ToString();
                            programLine = Regex.Match(line, @"\(\s*(.+?)\s*\)", RegexOptions.Singleline).Groups[1].Value.ToString();
                            //test.Rows.Add(file, nNumber,line);\
                        }
                        else if (Regex.IsMatch(line, @"\(\s*(.+?)\s*\)", RegexOptions.Singleline))
                        {
                            programLine = Regex.Match(line, @"\(\s*(.+?)\s*\)", RegexOptions.Singleline).Groups[1].Value.ToString();
                            //test.Rows.Add(file, nNumber, comment);
                        }
                        if (programLine != "")
                        {
                            //var fuzzyMatchValue = DuoVia.FuzzyStrings.StringExtensions.FuzzyEquals(stringtest, programLine, 0.75);
                            //var fuzzyMatchValue = DuoVia.FuzzyStrings.LevenshteinDistanceExtensions.LevenshteinDistance(stringtest, programLine);
                            //var fuzzyMatchValue = DuoVia.FuzzyStrings.StringExtensions.FuzzyMatch(stringtest, programLine);
                            test.Rows.Add(rowID, file, apsNo, nNumber, programLine);
                            rowID++;
                        }

                    }
                    //test.Rows.Add(file);

                }


            }
            dataGridView1.DataSource = test;
        }*/

        private void button2_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("test");
            DataTable dtall = new DataTable();
            dtall.Columns.Add("Directory", typeof(string));
            dtall.Columns.Add("Extension", typeof(string));
            dtall.Columns.Add("APS_No", typeof(string));
            dtall.Columns.Add("Worksheet", typeof(string));
            dtall.Columns.Add("SetupSheetType", typeof(string));
            dtall.Columns.Add("SetupNo", typeof(string));
            dtall.Columns.Add("ModDate", typeof(string));
            dtall.Columns.Add("No.", typeof(string));
            dtall.Columns.Add("T", typeof(string));
            dtall.Columns.Add("Toolholder", typeof(string));
            dtall.Columns.Add("S-O", typeof(string));
            dtall.Columns.Add("Insert", typeof(string));
            dtall.Columns.Add("P / E", typeof(string));
            dtall.Columns.Add("Comments", typeof(string));

           

            string directoryMain = @"D:\Data_Setups\"; //寻找文件路径
            //string directoryPTHSG = @"L:\Data_Setups_PT-HSG\";

            //string[] mainArray = Directory.GetFiles(directoryMain, "*.xls", SearchOption.AllDirectories);
            var mainArray = Directory.EnumerateFiles(directoryMain, "*.*", SearchOption.AllDirectories).Where(s => s.EndsWith(".xls") || s.EndsWith(".XLS") || s.EndsWith(".XLSX") || s.EndsWith(".xlsx"));
                       
            //string[] ptHSGArray = Directory.GetFiles(directoryPTHSG, "*.xls", SearchOption.AllDirectories);

            //string[] pathArray = mainArray.Concat(ptHSGArray).ToArray();
            string[] pathArray = mainArray.ToArray(); //修改--暂时不考虑 directoryPTHSG 文件夹        

            List<string> path = new List<string>();
            foreach (string p in pathArray)   //把找到的文件放入List中
            {
                path.Add(p);
            }

            foreach (string file in path)
            {
                //MessageBox.Show(file);
                if (!file.Contains("old") && Regex.IsMatch(file, @"D:\\\b((Data_Setups_PT-HSG)|(Data_Setups))\b\S+\\((?i)(docs|doc))\\\d{4}", RegexOptions.Singleline))

                    {
                    //MessageBox.Show(file.Split('\\').Last());
                    string apsNo = Regex.Match(file.Split('\\').Last(), @"(\d{4})", RegexOptions.Singleline).Groups[1].Value.ToString(); //输入正则表达式时，可以在双引号前加上@符号作为开头，这样就不需要再对其中的转义字符加上\
                    //MessageBox.Show(apsNo);
                    string connectionString = GetConnectionString(file);
                    //MessageBox.Show(connectionString);
                    try
                    {
                        using (OleDbConnection MyConnection = new OleDbConnection(connectionString))
                        {
                            MyConnection.Open();
                            OleDbCommand cmd = new OleDbCommand();
                            cmd.Connection = MyConnection;

                            // Get all Sheets in Excel File
                            DataTable dtSheet = MyConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            dataGridView1.DataSource = dtSheet;
                            //MessageBox.Show(dtSheet.ToString());

                            foreach (DataRow dr in dtSheet.Rows)
                            {
                                string sheetName = dr["TABLE_NAME"].ToString();
                                //MessageBox.Show(sheetName);

                                sheetName = sheetName.Replace("'", "");
                                //MessageBox.Show(sheetName);

                                if (!sheetName.EndsWith("$"))
                                    continue;

                                //dtall.Rows.Add(file, "", apsNo, sheetName);

                                OleDbDataAdapter objDA = new System.Data.OleDb.OleDbDataAdapter("select* from [" + sheetName + "]", MyConnection);
                                //MessageBox.Show(objDA.ToString());

                                DataSet excelDataSet = new DataSet();
                                objDA.Fill(excelDataSet);

                                //MessageBox.Show(objDA.ToString());

                                try
                                {
                                    dataGridView1.DataSource = excelDataSet.Tables[0];
                                    //MessageBox.Show(dataGridView1.DataSource.ToString());
                                    string extension = file.Split('.').Last();
                                    //MessageBox.Show(extension.ToString());
                                    sheetName = Regex.Match(sheetName, @"(.+?)\$", RegexOptions.Singleline).Groups[1].Value.ToString();
                                    //MessageBox.Show(sheetName);
                                    string setupType = excelDataSet.Tables[0].Rows[0].ItemArray[0].ToString();
                                    //MessageBox.Show(setupType);
                                    string setupNo = excelDataSet.Tables[0].Rows[2].ItemArray[0].ToString();
                                    //MessageBox.Show(setupNo);
                                    string modDate = "";
                                    string lineNo = "";
                                    string tNo = "";
                                    string toolHolder = "";
                                    string stickout = "";
                                    string insert = "";
                                    string pE = "";
                                    string comments = "";

                                    if (setupNo != " ")
                                    {
                                        //MessageBox.Show("test");
                                        if (setupType == "Lathe Setup Sheet")

                                        {

                                            //setupNo = excelDataSet.Tables[0].Rows[2].ItemArray[0].ToString();
                                            modDate = excelDataSet.Tables[0].Rows[0].ItemArray[43].ToString();


                                            for (int r1 = 0; r1 <= excelDataSet.Tables[0].Rows.Count - 1; r1++)
                                            {
                                                //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[0] + " -- " + excelDataSet.Tables[0].Rows[i].ItemArray[1]);
                                                //MessageBox.Show(excelDataSet.Tables[0].Rows[r1].ItemArray[0].ToString());
                                                if (excelDataSet.Tables[0].Rows[r1].ItemArray[0].ToString().StartsWith("Machine Tools List:"))
                                                {
                                                    //MessageBox.Show(r1.ToString());
                                                    //MessageBox.Show(excelDataSet.Tables[0].Rows[r1].ItemArray[0].ToString());
                                                    int? ac1 = null;
                                                    int? ac2 = null;
                                                    int? ac3 = null;
                                                    int? ac4 = null;
                                                    int? ac5 = null;
                                                    int? ac6 = null;
                                                    int? ac7 = null;

                                                    for (int c = 0; c <= excelDataSet.Tables[0].Columns.Count - 1; c++)
                                                    {
                                                        if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "No.")
                                                        {
                                                            ac1 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "T")
                                                        {
                                                            ac2 = c;
                                                        }
                                                        //else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "Toolholder")
                                                        else if (Regex.IsMatch(excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString(), @"(?i)(tool)\s*(holder)", RegexOptions.Singleline))
                                                        {
                                                            ac3 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "S-O")
                                                        {
                                                            ac4 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "Insert")
                                                        {
                                                            ac5 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "P / E")
                                                        {
                                                            ac6 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "Comments")
                                                        {
                                                            ac7 = c;
                                                        }
                                                    }

                                                    //MessageBox.Show(ac1.ToString());

                                                    for (int r2 = r1 + 2; r2 <= excelDataSet.Tables[0].Rows.Count - 1; r2++)
                                                    {
                                                        //if (excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString() == "" && excelDataSet.Tables[0].Rows[i+1].ItemArray[1].ToString() != "")// Run down until one No. has nothing in the Toolholder column below
                                                        //{
                                                        //    //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString());
                                                        //    break;
                                                        //}

                                                        if (excelDataSet.Tables[0].Rows[r2].ItemArray[0].ToString() == "Measuring Tools List:")// Run down until line below contains Measuring Tools List:
                                                        {
                                                            //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString());
                                                            break;
                                                        }

                                                        if (ac1 == null)
                                                        { lineNo = ""; }
                                                        else { lineNo = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac1.ToString())].ToString(); };
                                                        if (ac2 == null)
                                                        { tNo = ""; }
                                                        else { tNo = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac2.ToString())].ToString(); };
                                                        if (ac3 == null)
                                                        { toolHolder = ""; }
                                                        else { toolHolder = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac3.ToString())].ToString(); };
                                                        if (ac4 == null)
                                                        { stickout = ""; }
                                                        else { stickout = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac4.ToString())].ToString(); };
                                                        if (ac5 == null)
                                                        { insert = ""; }
                                                        else { insert = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac5.ToString())].ToString(); };
                                                        if (ac6 == null)
                                                        { pE = ""; }
                                                        else { pE = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac6.ToString())].ToString(); };
                                                        if (ac7 == null)
                                                        { comments = ""; }
                                                        else { comments = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac7.ToString())].ToString(); };


                                                        //string lineNo = excelDataSet.Tables[0].Rows[r2].ItemArray[ac1.GetValueOrDefault()].ToString();
                                                        //string tNo = excelDataSet.Tables[0].Rows[r2].ItemArray[ac2.GetValueOrDefault()].ToString();
                                                        ////string toolHolder = excelDataSet.Tables[0].Rows[r2].ItemArray[ac3].ToString();
                                                        ////string stickout = excelDataSet.Tables[0].Rows[r2].ItemArray[ac4].ToString();
                                                        ////string insert = excelDataSet.Tables[0].Rows[r2].ItemArray[ac5].ToString();
                                                        ////string pE = excelDataSet.Tables[0].Rows[r2].ItemArray[ac6].ToString();
                                                        ////string comments = excelDataSet.Tables[0].Rows[r2].ItemArray[ac7].ToString();

                                                        //MessageBox.Show(toolHolder);
                                                        if (toolHolder != "")
                                                        {
                                                            //dtall.Rows.Add(file, extension, apsNo, sheetName, setupType, setupNo, modDate, lineNo, tNo, toolHolder, stickout, insert, pE, comments);

                                                            SqlConnection con = new SqlConnection("server=DESKTOP-B5SS6RS;uid=admin;pwd=admin;database=DB1;");

                                                           // SqlCommand insertRow = new SqlCommand(@"insert into [DB1].[dbo].[APS_ToolList] ([File],[APS_No],[Sheet_Name],[Setup_Type],[Setup_No],[Mod_Date],[Line_No],[Tool_No]
                                                           //                                         ,[Tool_Holder],[Stick_Out],[Insert],[P/E],[Comment])
                                                           //Values (@file, @apsNo, @sheetName, @setupType, @setupNo, @modDate, @lineNo, @tNo, @toolHolder, @stickout, @insert, @pE, @comments);", con);

                                                            SqlCommand insertRow = new SqlCommand(@"insert into [DB1].[dbo].[APS_ToolList] ([File],[APS_No],[Sheet_Name],[Setup_Type],[Setup_No],[Mod_Date],[Line_No],[Tool_No]
                                                                                                    ,[Tool_Holder],[Stick_Out],[Insert],[P/E],[Comment])
                                                            Values (@file, @apsNo, @sheetName, @setupType, @setupNo, @modDate, @lineNo, @tNo, @toolHolder, @stickout, @insert, @pE, @comments);", con);


                                                            con.Open();
                                                            //MessageBox.Show(con.ToString());

                                                            insertRow.Parameters.Clear();

                                                            insertRow.Parameters.AddWithValue("@file", file);
                                                            insertRow.Parameters.AddWithValue("@apsNo", apsNo);
                                                            insertRow.Parameters.AddWithValue("@sheetName", sheetName);
                                                            insertRow.Parameters.AddWithValue("@setupType", setupType);
                                                            insertRow.Parameters.AddWithValue("@setupNo", setupNo);
                                                            insertRow.Parameters.AddWithValue("@modDate", modDate);
                                                            insertRow.Parameters.AddWithValue("@lineNo", lineNo);
                                                            insertRow.Parameters.AddWithValue("@tNo", tNo);
                                                            insertRow.Parameters.AddWithValue("@toolHolder", toolHolder);
                                                            insertRow.Parameters.AddWithValue("@stickout", stickout);
                                                            insertRow.Parameters.AddWithValue("@insert", insert);
                                                            insertRow.Parameters.AddWithValue("@pE", pE);
                                                            insertRow.Parameters.AddWithValue("@comments", comments);

                                                            insertRow.ExecuteNonQuery();
                                                            con.Close();
                                                        }
                                                    }
                                                }
                                            }
                                            //MessageBox.Show("Sheet");
                                        }
                                    
                                    //========================以下修改===========================================================
                                    else if (setupType == "NT dept. Lower Turret")
                                    {

                                        //setupNo = excelDataSet.Tables[0].Rows[2].ItemArray[0].ToString();
                                        modDate = excelDataSet.Tables[0].Rows[0].ItemArray[43].ToString();


                                        for (int r1 = 0; r1 <= excelDataSet.Tables[0].Rows.Count - 1; r1++)
                                        {
                                            //MessageBox.Show(excelDataSet.Tables[0].Rows[r1].ItemArray[0] + " -- " + excelDataSet.Tables[0].Rows[r1].ItemArray[1]);
                                            //MessageBox.Show(excelDataSet.Tables[0].Rows[r1].ItemArray[0].ToString());
                                            if (excelDataSet.Tables[0].Rows[r1].ItemArray[0].ToString().StartsWith("Machine Tools List for Lower Turret:"))
                                            {
                                                //MessageBox.Show(r1.ToString());
                                                //MessageBox.Show(excelDataSet.Tables[0].Rows[r1].ItemArray[0].ToString());
                                                int? ac1 = null;
                                                int? ac2 = null;
                                                int? ac3 = null;
                                                int? ac4 = null;
                                                int? ac5 = null;
                                                int? ac6 = null;
                                                int? ac7 = null;



                                                for (int c = 0; c <= excelDataSet.Tables[0].Columns.Count - 1; c++)
                                                {
                                                    //MessageBox.Show(excelDataSet.Tables[0].Rows[r1 + 2].ItemArray[c].ToString());
                                                    //MessageBox.Show(r1.ToString());
                                                    //MessageBox.Show(c.ToString());
                                                    if (excelDataSet.Tables[0].Rows[r1 + 2].ItemArray[c].ToString() == "No.")
                                                    {
                                                        ac1 = c;
                                                    }
                                                    else if (excelDataSet.Tables[0].Rows[r1 + 2].ItemArray[c].ToString() == "T")
                                                    {
                                                        ac2 = c;
                                                    }
                                                    //else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "Toolholder")
                                                    else if (Regex.IsMatch(excelDataSet.Tables[0].Rows[r1 + 2].ItemArray[c].ToString(), @"(?i)(tool)\s*(holder)[\s\S]*", RegexOptions.Singleline))
                                                    {
                                                        ac3 = c;
                                                    }
                                                    else if (excelDataSet.Tables[0].Rows[r1 + 2].ItemArray[c].ToString() == "S-O")
                                                    {
                                                        ac4 = c;
                                                    }
                                                    else if (excelDataSet.Tables[0].Rows[r1 + 2].ItemArray[c].ToString() == "Insert")
                                                    {
                                                        ac5 = c;
                                                    }
                                                    else if (excelDataSet.Tables[0].Rows[r1 + 2].ItemArray[c].ToString() == "P / E")
                                                    {
                                                        ac6 = c;
                                                    }
                                                    else if (excelDataSet.Tables[0].Rows[r1 + 2].ItemArray[c].ToString() == "Comments")
                                                    {
                                                        ac7 = c;
                                                    }
                                                }

                                                for (int r2 = r1 + 2; r2 <= excelDataSet.Tables[0].Rows.Count - 1; r2++)
                                                {
                                                    //if (excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString() == "" && excelDataSet.Tables[0].Rows[i+1].ItemArray[1].ToString() != "")// Run down until one No. has nothing in the Toolholder column below
                                                    //{
                                                    //    //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString());
                                                    //    break;
                                                    //}
                                                    //MessageBox.Show(excelDataSet.Tables[0].Rows[r2].ItemArray[0].ToString());
                                                    if (excelDataSet.Tables[0].Rows[r2].ItemArray[0].ToString() == "Measuring Tools List:")// Run down until line below contains Measuring Tools List:
                                                    {
                                                        //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString());
                                                        break;
                                                    }

                                                    if (ac1 == null)
                                                    { lineNo = ""; }
                                                    else { lineNo = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac1.ToString())].ToString(); };
                                                    if (ac2 == null)
                                                    { tNo = ""; }
                                                    else { tNo = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac2.ToString())].ToString(); };
                                                    if (ac3 == null)
                                                    { toolHolder = ""; }
                                                    else { toolHolder = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac3.ToString())].ToString(); };
                                                    if (ac4 == null)
                                                    { stickout = ""; }
                                                    else { stickout = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac4.ToString())].ToString(); };
                                                    if (ac5 == null)
                                                    { insert = ""; }
                                                    else { insert = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac5.ToString())].ToString(); };
                                                    if (ac6 == null)
                                                    { pE = ""; }
                                                    else { pE = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac6.ToString())].ToString(); };
                                                    if (ac7 == null)
                                                    { comments = ""; }
                                                    else { comments = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac7.ToString())].ToString(); };


                                                    if (lineNo == "Pot.") //Run down until line below contains NT dept. Tool Spindle:
                                                    {
                                                        break;
                                                    }


                                                    //string lineNo = excelDataSet.Tables[0].Rows[r2].ItemArray[ac1.GetValueOrDefault()].ToString();
                                                    //string tNo = excelDataSet.Tables[0].Rows[r2].ItemArray[ac2.GetValueOrDefault()].ToString();
                                                    ////string toolHolder = excelDataSet.Tables[0].Rows[r2].ItemArray[ac3].ToString();
                                                    ////string stickout = excelDataSet.Tables[0].Rows[r2].ItemArray[ac4].ToString();
                                                    ////string insert = excelDataSet.Tables[0].Rows[r2].ItemArray[ac5].ToString();
                                                    ////string pE = excelDataSet.Tables[0].Rows[r2].ItemArray[ac6].ToString();
                                                    ////string comments = excelDataSet.Tables[0].Rows[r2].ItemArray[ac7].ToString();

                                                    //MessageBox.Show(toolHolder);
                                                    if (toolHolder != "")
                                                    {
                                                        //dtall.Rows.Add(file, extension, apsNo, sheetName, setupType, setupNo, modDate, lineNo, tNo, toolHolder, stickout, insert, pE, comments);

                                                        SqlConnection con = new SqlConnection("server=DESKTOP-B5SS6RS;uid=admin;pwd=admin;database=DB1;");

                                                        // SqlCommand insertRow = new SqlCommand(@"insert into [DB1].[dbo].[APS_ToolList] ([File],[APS_No],[Sheet_Name],[Setup_Type],[Setup_No],[Mod_Date],[Line_No],[Tool_No]
                                                        //                                         ,[Tool_Holder],[Stick_Out],[Insert],[P/E],[Comment])
                                                        //Values (@file, @apsNo, @sheetName, @setupType, @setupNo, @modDate, @lineNo, @tNo, @toolHolder, @stickout, @insert, @pE, @comments);", con);

                                                        SqlCommand insertRow = new SqlCommand(@"insert into [DB1].[dbo].[APS_ToolList] ([File],[APS_No],[Sheet_Name],[Setup_Type],[Setup_No],[Mod_Date],[Line_No],[Tool_No]
                                                                                                     ,[Tool_Holder],[Stick_Out],[Insert],[P/E],[Comment])
                                                             Values (@file, @apsNo, @sheetName, @setupType, @setupNo, @modDate, @lineNo, @tNo, @toolHolder, @stickout, @insert, @pE, @comments);", con);


                                                        con.Open();
                                                        //MessageBox.Show(con.ToString());

                                                        insertRow.Parameters.Clear();

                                                        insertRow.Parameters.AddWithValue("@file", file);
                                                        insertRow.Parameters.AddWithValue("@apsNo", apsNo);
                                                        insertRow.Parameters.AddWithValue("@sheetName", sheetName);
                                                        insertRow.Parameters.AddWithValue("@setupType", setupType);
                                                        insertRow.Parameters.AddWithValue("@setupNo", setupNo);
                                                        insertRow.Parameters.AddWithValue("@modDate", modDate);
                                                        insertRow.Parameters.AddWithValue("@lineNo", lineNo);
                                                        insertRow.Parameters.AddWithValue("@tNo", tNo);
                                                        insertRow.Parameters.AddWithValue("@toolHolder", toolHolder);
                                                        insertRow.Parameters.AddWithValue("@stickout", stickout);
                                                        insertRow.Parameters.AddWithValue("@insert", insert);
                                                        insertRow.Parameters.AddWithValue("@pE", pE);
                                                        insertRow.Parameters.AddWithValue("@comments", comments);

                                                        insertRow.ExecuteNonQuery();
                                                        con.Close();
                                                    }
                                                }
                                            }
                                        }
                                        //MessageBox.Show("Sheet");
                                    }

                                    //========================修改结束===========================================================

                                    else
                                    {
                                        //dtall.Rows.Add(file, extension, apsNo, sheetName, setupType, setupNo, modDate, lineNo, tNo, toolHolder, stickout, insert, pE, comments);

                                        SqlConnection con = new SqlConnection("server=DESKTOP-B5SS6RS;uid=admin;pwd=admin;database=DB1;");

                                        SqlCommand insertRow = new SqlCommand(@"insert into [DB1].[dbo].[APS_ToolList] ([File],[APS_No],[Sheet_Name],[Setup_Type],[Setup_No],[Mod_Date],[Line_No],[Tool_No]
                                                                                             ,[Tool_Holder],[Stick_Out],[Insert],[P/E],[Comment])
                                                     Values (@file, @apsNo, @sheetName, @setupType, @setupNo, @modDate, @lineNo, @tNo, @toolHolder, @stickout, @insert, @pE, @comments);", con);


                                        con.Open();


                                        insertRow.Parameters.Clear();

                                        insertRow.Parameters.AddWithValue("@file", file);
                                        insertRow.Parameters.AddWithValue("@apsNo", apsNo);
                                        insertRow.Parameters.AddWithValue("@sheetName", sheetName);
                                        insertRow.Parameters.AddWithValue("@setupType", setupType);
                                        insertRow.Parameters.AddWithValue("@setupNo", setupNo);
                                        insertRow.Parameters.AddWithValue("@modDate", modDate);
                                        insertRow.Parameters.AddWithValue("@lineNo", lineNo);
                                        insertRow.Parameters.AddWithValue("@tNo", tNo);
                                        insertRow.Parameters.AddWithValue("@toolHolder", toolHolder);
                                        insertRow.Parameters.AddWithValue("@stickout", stickout);
                                        insertRow.Parameters.AddWithValue("@insert", insert);
                                        insertRow.Parameters.AddWithValue("@pE", pE);
                                        insertRow.Parameters.AddWithValue("@comments", comments);

                                        insertRow.ExecuteNonQuery();
                                        con.Close();
                                    }
                                    }

                                }
                                catch (System.IndexOutOfRangeException ex) { }
                            }
                            cmd = null;
                            MyConnection.Close();
                        }
                    }
                    catch (OleDbException ex1) { }

                    dataGridView1.DataSource = dtall;
                }
            }
            Application.Exit();
        }



       private void button3_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("test");
            DataTable dtall = new DataTable();
            dtall.Columns.Add("Directory", typeof(string));
            dtall.Columns.Add("Extension", typeof(string));
            dtall.Columns.Add("APS_No", typeof(string));
            dtall.Columns.Add("Worksheet", typeof(string));
            dtall.Columns.Add("SetupSheetType", typeof(string));
            dtall.Columns.Add("SetupNo", typeof(string));
            dtall.Columns.Add("ModDate", typeof(string));
            dtall.Columns.Add("No.", typeof(string));
            dtall.Columns.Add("T", typeof(string));
            dtall.Columns.Add("MeasuringTool", typeof(string));
            dtall.Columns.Add("To Measure", typeof(string));
            dtall.Columns.Add("I.D", typeof(string));
            dtall.Columns.Add("O.D", typeof(string));
            dtall.Columns.Add("Exten.", typeof(string));
            dtall.Columns.Add("Comments", typeof(string));

            List<string> path = new List<string>();

            string directoryMain = @"D:\Data_Setups\";
            //string directoryPTHSG = @"D:\Data_Setups_PT-HSG\";

            string[] mainArray = Directory.GetFiles(directoryMain, "*.xlsx", SearchOption.AllDirectories);

            //string[] ptHSGArray = Directory.GetFiles(directoryPTHSG, "*.xls", SearchOption.AllDirectories);

            //string[] pathArray = mainArray.Concat(ptHSGArray).ToArray();

            string[] pathArray = mainArray.ToArray(); //修改 

            foreach (string p in pathArray)
            {
                path.Add(p);
            }
            foreach (string file in path)
            {
                //MessageBox.Show(file);
                if (!file.Contains("old") && Regex.IsMatch(file, @"D:\\\b((Data_Setups_PT-HSG)|(Data_Setups))\b\S+\\((?i)(docs|doc))\\\d{4}", RegexOptions.Singleline))

                {
                    //MessageBox.Show(file.Split('\\').Last());
                    string apsNo = Regex.Match(file.Split('\\').Last(), @"(\d{4})", RegexOptions.Singleline).Groups[1].Value.ToString();
                    //MessageBox.Show(apsNo);
                    string connectionString = GetConnectionString(file);

                    //MessageBox.Show(connectionString);
                    try
                    {
                        using (OleDbConnection MyConnection = new OleDbConnection(connectionString))
                        {
                            MyConnection.Open();
                            OleDbCommand cmd = new OleDbCommand();
                            cmd.Connection = MyConnection;

                            // Get all Sheets in Excel File
                            DataTable dtSheet = MyConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            //dataGridView1.DataSource = dtSheet;

                            foreach (DataRow dr in dtSheet.Rows)
                            {
                                string sheetName = dr["TABLE_NAME"].ToString();
                                sheetName = sheetName.Replace("'", "");

                                if (!sheetName.EndsWith("$"))
                                    continue;

                                //dtall.Rows.Add(file, "", apsNo, sheetName);

                                OleDbDataAdapter objDA = new System.Data.OleDb.OleDbDataAdapter("select* from [" + sheetName + "]", MyConnection);
                                DataSet excelDataSet = new DataSet();
                                objDA.Fill(excelDataSet);

                                try
                                {
                                    //dataGridView1.DataSource = excelDataSet.Tables[0];
                                    string extension = file.Split('.').Last();
                                    sheetName = Regex.Match(sheetName, @"(.+?)\$", RegexOptions.Singleline).Groups[1].Value.ToString();
                                    string setupType = excelDataSet.Tables[0].Rows[0].ItemArray[0].ToString();
                                    string setupNo = excelDataSet.Tables[0].Rows[2].ItemArray[0].ToString();
                                    string modDate = "";
                                    string lineNo = "";
                                    string tNo = "";
                                    string measureTool = "";
                                    string toMeasure = "";
                                    string id = "";
                                    string od = "";
                                    string exten = "";
                                    string comments = "";

                                    if (setupNo != " ")
                                    {
                                        //MessageBox.Show("test");
                                        if (setupType == "Lathe Setup Sheet")

                                        {

                                            //setupNo = excelDataSet.Tables[0].Rows[2].ItemArray[0].ToString();
                                            modDate = excelDataSet.Tables[0].Rows[0].ItemArray[43].ToString();


                                            for (int r1 = 0; r1 <= excelDataSet.Tables[0].Rows.Count - 1; r1++)
                                            {
                                                //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[0] + " -- " + excelDataSet.Tables[0].Rows[i].ItemArray[1]);
                                                //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[0].ToString());
                                                if (excelDataSet.Tables[0].Rows[r1].ItemArray[0].ToString().StartsWith("Measuring Tools List:"))
                                                {
                                                    //MessageBox.Show(i.ToString());
                                                    //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[0].ToString());
                                                    int? ac1 = null;
                                                    int? ac2 = null;
                                                    int? ac3 = null;
                                                    int? ac4 = null;
                                                    int? ac5 = null;
                                                    int? ac6 = null;
                                                    int? ac7 = null;
                                                    int? ac8 = null;

                                                    for (int c = 0; c <= excelDataSet.Tables[0].Columns.Count - 1; c++)
                                                    {
                                                        if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "No.")
                                                        {
                                                            ac1 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "T")
                                                        {
                                                            ac2 = c;
                                                        }
                                                        //else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "Toolholder")
                                                        else if (Regex.IsMatch(excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString(), @"(?i)(Measuring)\s*(Tool)", RegexOptions.Singleline))
                                                        {
                                                            ac3 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "To Measure:")
                                                        {
                                                            ac4 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "I.D")
                                                        {
                                                            ac5 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "O.D")
                                                        {
                                                            ac6 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "Exten.")
                                                        {
                                                            ac7 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "Comments")
                                                        {
                                                            ac8 = c;
                                                        }
                                                    }

                                                    //MessageBox.Show(ac1.ToString());

                                                    for (int r2 = r1 + 2; r2 <= excelDataSet.Tables[0].Rows.Count - 1; r2++)
                                                    {
                                                        //if (excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString() == "" && excelDataSet.Tables[0].Rows[i+1].ItemArray[1].ToString() != "")// Run down until one No. has nothing in the Toolholder column below
                                                        //{
                                                        //    //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString());
                                                        //    break;
                                                        //}

                                                        if (excelDataSet.Tables[0].Rows[r2].ItemArray[0].ToString() == "Additional Comments:")// Run down until line below contains Measuring Tools List:
                                                        {
                                                            //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString());
                                                            break;
                                                        }

                                                        if (ac1 == null)
                                                        { lineNo = ""; }
                                                        else { lineNo = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac1.ToString())].ToString(); };
                                                        if (ac2 == null)
                                                        { tNo = ""; }
                                                        else { tNo = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac2.ToString())].ToString(); };
                                                        if (ac3 == null)
                                                        { measureTool = ""; }
                                                        else { measureTool = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac3.ToString())].ToString(); };
                                                        if (ac4 == null)
                                                        { toMeasure = ""; }
                                                        else { toMeasure = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac4.ToString())].ToString(); };
                                                        if (ac5 == null)
                                                        { id = ""; }
                                                        else { id = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac5.ToString())].ToString(); };
                                                        if (ac6 == null)
                                                        { od = ""; }
                                                        else { od = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac6.ToString())].ToString(); };
                                                        if (ac7 == null)
                                                        { exten = ""; }
                                                        else { exten = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac7.ToString())].ToString(); };
                                                        if (ac8 == null)
                                                        { comments = ""; }
                                                        else { comments = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac8.ToString())].ToString(); };

                                                        if (measureTool != "")
                                                        {
                                                            //dtall.Rows.Add(file, extension, apsNo, sheetName, setupType, setupNo, modDate, lineNo, tNo, measureTool, toMeasure, id, od, exten, comments);

                                                            SqlConnection con = new SqlConnection("server=DESKTOP-B5SS6RS;uid=admin;pwd=admin;database=DB1;");

                                                            SqlCommand insertRow = new SqlCommand(@"insert into [APS_MeasuringToolList] ([File],[APS_No],[Sheet_Name],[Setup_Type],[Setup_No],[Mod_Date],[Line_No],[Tool_No]
                                                                                                    ,[Measuring_Tool_No],[To_Measure],[I.D],[O.D],[Exten.],[Comment])
                                                            Values (@file, @apsNo, @sheetName, @setupType, @setupNo, @modDate, @lineNo, @tNo, @measureTool, @toMeasure, @id, @od ,@exten, @comments);", con);


                                                            con.Open();
                                                            insertRow.Parameters.Clear();

                                                            insertRow.Parameters.AddWithValue("@file", file);
                                                            insertRow.Parameters.AddWithValue("@apsNo", apsNo);
                                                            insertRow.Parameters.AddWithValue("@sheetName", sheetName);
                                                            insertRow.Parameters.AddWithValue("@setupType", setupType);
                                                            insertRow.Parameters.AddWithValue("@setupNo", setupNo);
                                                            insertRow.Parameters.AddWithValue("@modDate", modDate);
                                                            insertRow.Parameters.AddWithValue("@lineNo", lineNo);
                                                            insertRow.Parameters.AddWithValue("@tNo", tNo);
                                                            insertRow.Parameters.AddWithValue("@measureTool", measureTool);
                                                            insertRow.Parameters.AddWithValue("@toMeasure", toMeasure);
                                                            insertRow.Parameters.AddWithValue("@id", id);
                                                            insertRow.Parameters.AddWithValue("@od", od);
                                                            insertRow.Parameters.AddWithValue("@exten", exten);
                                                            insertRow.Parameters.AddWithValue("@comments", comments);

                                                            insertRow.ExecuteNonQuery();
                                                            con.Close();
                                                        }
                                                    }
                                                }
                                            }
                                            //MessageBox.Show("Sheet");
                                        }
//========================以下修改===========================================================
                                        else if (setupType == "NT dept. Lower Turret")
                                        {
                                            //setupNo = excelDataSet.Tables[0].Rows[2].ItemArray[0].ToString();
                                            modDate = excelDataSet.Tables[0].Rows[0].ItemArray[43].ToString();


                                            for (int r1 = 0; r1 <= excelDataSet.Tables[0].Rows.Count - 1; r1++)
                                            {
                                                //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[0] + " -- " + excelDataSet.Tables[0].Rows[i].ItemArray[1]);
                                                //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[0].ToString());
                                                if (excelDataSet.Tables[0].Rows[r1].ItemArray[0].ToString().StartsWith("Measuring Tools List:"))
                                                {
                                                    //MessageBox.Show(i.ToString());
                                                    //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[0].ToString());
                                                    int? ac1 = null;
                                                    int? ac2 = null;
                                                    int? ac3 = null;
                                                    int? ac4 = null;
                                                    int? ac5 = null;
                                                    int? ac6 = null;
                                                    int? ac7 = null;
                                                    int? ac8 = null;

                                                    for (int c = 0; c <= excelDataSet.Tables[0].Columns.Count - 1; c++)
                                                    {
                                                        if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "No.")
                                                        {
                                                            //MessageBox.Show(r1.ToString());
                                                            ac1 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "T")
                                                        {
                                                            ac2 = c;
                                                        }
                                                        //else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "Toolholder")
                                                        else if (Regex.IsMatch(excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString(), @"(?i)(Measuring)\s*(Tool)", RegexOptions.Singleline))
                                                        {
                                                            ac3 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "To Measure:")
                                                        {
                                                            ac4 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "I.D")
                                                        {
                                                            ac5 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "O.D")
                                                        {
                                                            ac6 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "Exten.")
                                                        {
                                                            ac7 = c;
                                                        }
                                                        else if (excelDataSet.Tables[0].Rows[r1 + 1].ItemArray[c].ToString() == "Comments")
                                                        {
                                                            ac8 = c;
                                                        }
                                                    }

                                                    //MessageBox.Show(ac1.ToString());

                                                    for (int r2 = r1 + 2; r2 <= excelDataSet.Tables[0].Rows.Count - 1; r2++)
                                                    {
                                                        //if (excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString() == "" && excelDataSet.Tables[0].Rows[i+1].ItemArray[1].ToString() != "")// Run down until one No. has nothing in the Toolholder column below
                                                        //{
                                                        //    //MessageBox.Show(excelDataSet.Tables[0].Rows[i].ItemArray[1].ToString());
                                                        //    break;
                                                        //}

                                                        string st1 = excelDataSet.Tables[0].Rows[r2].ItemArray[1].ToString(); //B-L
                                                        string st2 = excelDataSet.Tables[0].Rows[r2].ItemArray[12].ToString(); //M-X
                                                        string st3 = excelDataSet.Tables[0].Rows[r2].ItemArray[24].ToString(); //Y-Z
                                                        string st4 = excelDataSet.Tables[0].Rows[r2].ItemArray[26].ToString(); //AA-AB
                                                        string st5 = excelDataSet.Tables[0].Rows[r2].ItemArray[28].ToString(); //AC-AD
                                                        string st6 = excelDataSet.Tables[0].Rows[r2].ItemArray[30].ToString(); //AE-AV

                                                        //messagebox.show(st1.tostring());
                                                        //messagebox.show(st2.tostring());
                                                        //messagebox.show(st3.tostring());
                                                        //messagebox.show(st4.tostring());
                                                        //messagebox.show(st5.tostring());
                                                        //messagebox.show(st6.tostring());

                                                        if (st1 == "" && st2 == "" && st3 == "" && st4 == "" && st5 == "" && st6 == "")// Run down until line below contains Measuring Tools List:
                                                        {                                                          
                                                            break;
                                                        }

                                                        if (ac1 == null)
                                                        { lineNo = ""; }
                                                        else { lineNo = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac1.ToString())].ToString(); };
                                                        if (ac2 == null)
                                                        { tNo = ""; }
                                                        else { tNo = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac2.ToString())].ToString(); };
                                                        if (ac3 == null)
                                                        { measureTool = ""; }
                                                        else { measureTool = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac3.ToString())].ToString(); };
                                                        if (ac4 == null)
                                                        { toMeasure = ""; }
                                                        else { toMeasure = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac4.ToString())].ToString(); };
                                                        if (ac5 == null)
                                                        { id = ""; }
                                                        else { id = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac5.ToString())].ToString(); };
                                                        if (ac6 == null)
                                                        { od = ""; }
                                                        else { od = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac6.ToString())].ToString(); };
                                                        if (ac7 == null)
                                                        { exten = ""; }
                                                        else { exten = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac7.ToString())].ToString(); };
                                                        if (ac8 == null)
                                                        { comments = ""; }
                                                        else { comments = excelDataSet.Tables[0].Rows[r2].ItemArray[Int32.Parse(ac8.ToString())].ToString(); };

                                                        if (measureTool != "")
                                                        {
                                                            //dtall.Rows.Add(file, extension, apsNo, sheetName, setupType, setupNo, modDate, lineNo, tNo, measureTool, toMeasure, id, od, exten, comments);

                                                            SqlConnection con = new SqlConnection("server=DESKTOP-B5SS6RS;uid=admin;pwd=admin;database=DB1;");

                                                            SqlCommand insertRow = new SqlCommand(@"insert into [APS_MeasuringToolList] ([File],[APS_No],[Sheet_Name],[Setup_Type],[Setup_No],[Mod_Date],[Line_No],[Tool_No]
                                                                                                    ,[Measuring_Tool_No],[To_Measure],[I.D],[O.D],[Exten.],[Comment])
                                                            Values (@file, @apsNo, @sheetName, @setupType, @setupNo, @modDate, @lineNo, @tNo, @measureTool, @toMeasure, @id, @od ,@exten, @comments);", con);


                                                            con.Open();
                                                            insertRow.Parameters.Clear();

                                                            insertRow.Parameters.AddWithValue("@file", file);
                                                            insertRow.Parameters.AddWithValue("@apsNo", apsNo);
                                                            insertRow.Parameters.AddWithValue("@sheetName", sheetName);
                                                            insertRow.Parameters.AddWithValue("@setupType", setupType);
                                                            insertRow.Parameters.AddWithValue("@setupNo", setupNo);
                                                            insertRow.Parameters.AddWithValue("@modDate", modDate);
                                                            insertRow.Parameters.AddWithValue("@lineNo", lineNo);
                                                            insertRow.Parameters.AddWithValue("@tNo", tNo);
                                                            insertRow.Parameters.AddWithValue("@measureTool", measureTool);
                                                            insertRow.Parameters.AddWithValue("@toMeasure", toMeasure);
                                                            insertRow.Parameters.AddWithValue("@id", id);
                                                            insertRow.Parameters.AddWithValue("@od", od);
                                                            insertRow.Parameters.AddWithValue("@exten", exten);
                                                            insertRow.Parameters.AddWithValue("@comments", comments);

                                                            insertRow.ExecuteNonQuery();
                                                            con.Close();
                                                        }
                                                    }
                                                }
                                            }
                                            //MessageBox.Show("Sheet");
                                        }
//========================修改结束===========================================================

                                        else
                                        {
                                            //dtall.Rows.Add(file, extension, apsNo, sheetName, setupType, setupNo, modDate, lineNo, tNo, measureTool, toMeasure, id, od, exten, comments);

                                            SqlConnection con = new SqlConnection("server=DESKTOP-B5SS6RS;uid=admin;pwd=admin;database=DB1;");

                                            SqlCommand insertRow = new SqlCommand(@"insert into [APS_MeasuringToolList] ([File],[APS_No],[Sheet_Name],[Setup_Type],[Setup_No],[Mod_Date],[Line_No],[Tool_No]
                                                                                                    ,[Measuring_Tool_No],[To_Measure],[I.D],[O.D],[Exten.],[Comment])
                                                            Values (@file, @apsNo, @sheetName, @setupType, @setupNo, @modDate, @lineNo, @tNo, @measureTool, @toMeasure, @id, @od ,@exten, @comments);", con);


                                            con.Open();
                                            insertRow.Parameters.Clear();

                                            insertRow.Parameters.AddWithValue("@file", file);
                                            insertRow.Parameters.AddWithValue("@apsNo", apsNo);
                                            insertRow.Parameters.AddWithValue("@sheetName", sheetName);
                                            insertRow.Parameters.AddWithValue("@setupType", setupType);
                                            insertRow.Parameters.AddWithValue("@setupNo", setupNo);
                                            insertRow.Parameters.AddWithValue("@modDate", modDate);
                                            insertRow.Parameters.AddWithValue("@lineNo", lineNo);
                                            insertRow.Parameters.AddWithValue("@tNo", tNo);
                                            insertRow.Parameters.AddWithValue("@measureTool", measureTool);
                                            insertRow.Parameters.AddWithValue("@toMeasure", toMeasure);
                                            insertRow.Parameters.AddWithValue("@id", id);
                                            insertRow.Parameters.AddWithValue("@od", od);
                                            insertRow.Parameters.AddWithValue("@exten", exten);
                                            insertRow.Parameters.AddWithValue("@comments", comments);

                                            insertRow.ExecuteNonQuery();
                                            con.Close();
                                        }
                                    }

                                }
                                catch (System.IndexOutOfRangeException ex) { }

                            }

                            cmd = null;
                            MyConnection.Close();
                        }
                    }
                    catch (OleDbException ex1) { }

                    dataGridView1.DataSource = dtall;
                }

            }
            Application.Exit();
        }

    }
}

